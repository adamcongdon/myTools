SnapCreator.exe 0 0 1 "GUID" VMID VMID ...

1st	(0) =	transportable
2nd	(0) =	persistent
3rd	(1) =	crashconsistent
4th	("GUID")=	VSS Provider ID see below
5th	(VMID)	=	VM GUID, can add as many as needed for test	



		//Dell HW provider d4689bdf-7b60-4f6e-9afb-2d13c01b12ea
		//CSV software provider 400a2ff4-5eb1-44b0-8a05-1fcac0bcf9ff
		//Software provider b5946137-7b9f-4925-af80-51abd60b20d5